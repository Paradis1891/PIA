package se.paradis1891.paradismarket

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private val bg = Color(0xFF090D14)
private val panel = Color(0xFF151D29)
private val muted = Color(0xFF91A0B5)
private val green = Color(0xFF35D49A)
private val red = Color(0xFFFF647C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ParadisMarketApp() }
    }
}

@Composable
fun ParadisMarketApp() {
    var instruments by remember { mutableStateOf(initialInstruments) }
    var selected by remember { mutableStateOf("saab-b") }
    var quotes by remember { mutableStateOf<Map<String, Quote>>(emptyMap()) }
    var status by remember { mutableStateOf("Inväntar anslutning till marknadsdata") }
    var lastUpdate by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val repo = remember { QuoteRepository() }

    LaunchedEffect(Unit) {
        while (true) {
            try {
                val fresh = repo.fetchQuotes(instruments)
                if (fresh.isNotEmpty()) {
                    quotes = fresh.associateBy { it.instrumentId }
                    status = "Yahoo Finance ansluten · kurser kan vara fördröjda"
                    lastUpdate = fresh.maxOfOrNull { it.updatedAt }.orEmpty()
                } else {
                    status = "Yahoo Finance svarade utan kurser · försöker igen"
                }
            } catch (e: Exception) {
                status = "Datafel: ${e.message ?: "kunde inte hämta kurser"}"
            }
            delay(30_000)
        }
    }

    val active = instruments.firstOrNull { it.id == selected } ?: instruments.first()
    val quote = quotes[selected]

    MaterialTheme(colorScheme = darkColorScheme(
        background = bg, surface = panel, primary = Color(0xFF70A7FF),
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(bg).padding(horizontal = 20.dp, vertical = 24.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("PARADIS", color = Color(0xFF70A7FF), fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("MARKET", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                }
                Text("LIVE", color = green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(28.dp))
            Text("MARKNAD", color = muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                items(instruments) { item ->
                    val isSelected = selected == item.id
                    Row(
                        Modifier.fillMaxWidth().background(if (isSelected) Color(0xFF1C2B40) else panel, RoundedCornerShape(16.dp))
                            .clickable { selected = item.id }.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(item.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(item.symbol, color = muted, fontSize = 12.sp)
                        }
                        val q = quotes[item.id]
                        Column(horizontalAlignment = Alignment.End) {
                            Text(q?.let { format(it.price) } ?: "—", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text(q?.let { format(it.changePercent) + "%" } ?: "Ej tillgänglig",
                                color = q?.let { if (it.changePercent >= 0) green else red } ?: muted, fontSize = 12.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Column(Modifier.fillMaxWidth().background(panel, RoundedCornerShape(22.dp)).padding(20.dp)) {
                Text(active.name, color = muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text(quote?.let { format(it.price) } ?: "— — —", color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Bold)
                Text(quote?.let { format(it.changePercent) + "%" } ?: "Inväntar verifierad kursdata",
                    color = quote?.let { if (it.changePercent >= 0) green else red } ?: muted, fontSize = 17.sp)
                Spacer(Modifier.height(18.dp))
                HorizontalDivider(color = Color(0xFF2A3545))
                Spacer(Modifier.height(12.dp))
                Text(status, color = if (quotes.isNotEmpty()) green else muted, fontSize = 12.sp)
                if (lastUpdate.isNotBlank()) Text("Senast: $lastUpdate", color = muted, fontSize = 11.sp)
                Text("Uppdateringsintervall: 30 sekunder", color = muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(10.dp))
            Text("Källa: Yahoo Finance. Kurser kan vara fördröjda och är inte garanterat realtid.", color = muted, fontSize = 10.sp)
        }
    }
}

private fun format(value: Double): String = String.format(Locale("sv", "SE"), "%,.2f", value)
