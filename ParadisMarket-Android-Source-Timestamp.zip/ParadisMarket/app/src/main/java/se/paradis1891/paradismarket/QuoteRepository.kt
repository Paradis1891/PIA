package se.paradis1891.paradismarket

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/** Direct Yahoo Finance chart API client. Yahoo data may be delayed and the unofficial endpoint can change. */
class QuoteRepository {
    private val client = OkHttpClient.Builder()
        .callTimeout(12, TimeUnit.SECONDS)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun fetchQuotes(instruments: List<Instrument>): List<Quote> = withContext(Dispatchers.IO) {
        instruments.mapNotNull { instrument ->
            runCatching { fetchOne(instrument) }.getOrNull()
        }
    }

    private fun fetchOne(instrument: Instrument): Quote {
        val url = "https://query1.finance.yahoo.com/v8/finance/chart/${instrument.symbol}".toHttpUrl()
            .newBuilder()
            .addQueryParameter("range", "1d")
            .addQueryParameter("interval", "1m")
            .build()
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            .header("Accept", "application/json")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Yahoo Finance ${response.code}")
            val root = JSONObject(response.body?.string() ?: error("Tomt svar från Yahoo Finance"))
            val chart = root.getJSONObject("chart")
            chart.optJSONObject("error")?.let { if (!it.isNull("description")) error(it.optString("description")) }
            val result = chart.getJSONArray("result").getJSONObject(0)
            val meta = result.getJSONObject("meta")
            val price = meta.optDouble("regularMarketPrice", Double.NaN)
            val previous = meta.optDouble("chartPreviousClose", meta.optDouble("previousClose", Double.NaN))
            if (!price.isFinite() || price <= 0.0) error("Yahoo Finance saknar aktuell kurs för ${instrument.symbol}")
            val change = if (previous.isFinite() && previous > 0.0) ((price - previous) / previous) * 100.0 else 0.0
            val marketTime = meta.optLong("regularMarketTime", System.currentTimeMillis() / 1000)
            val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale("sv", "SE"))
            formatter.timeZone = TimeZone.getTimeZone("Europe/Stockholm")
            Quote(
                instrumentId = instrument.id,
                price = price,
                changePercent = change,
                updatedAt = formatter.format(Date(marketTime * 1000)),
                updatedAtEpochSeconds = marketTime,
                source = "Yahoo Finance · ${meta.optString("currency", instrument.currency)} · kan vara fördröjd"
            )
        }
    }
}
