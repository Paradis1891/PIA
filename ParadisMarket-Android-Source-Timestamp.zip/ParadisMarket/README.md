# Paradis Market

Android-app (Kotlin + Jetpack Compose) för en enkel, lättläst marknadsskärm.

## Funktioner
- Mörkt gränssnitt med stora kurssiffror.
- SAAB B och Guld förvalda; instrumentlistan är enkel att utöka.
- Hämtar data var femte sekund från en konfigurerbar HTTPS-backend.
- Visar aldrig påhittade kurser när datakällan saknas eller felar.

## Viktigt om marknadsdata
Avanza-åtkomst är inte implementerad eller verifierad i den här versionen. Appen förväntar sig en backend med `GET /quotes` som returnerar:

```json
{
  "quotes": [
    {
      "instrumentId": "saab-b",
      "price": 250.1,
      "changePercent": 1.25,
      "updatedAt": "2026-11-10T10:00:00+01:00",
      "source": "Dataleverantör"
    }
  ]
}
```

Instrument-ID:n: `saab-b` och `gold`. Backend måste använda en datakälla vars licens och villkor tillåter visning i appen.

## Bygg
Öppna projektet i Android Studio (JDK 17, Android SDK 35) och bygg `app`.

Sätt `MARKET_API_BASE_URL` i `~/.gradle/gradle.properties`, exempelvis:
`MARKET_API_BASE_URL=https://din-backend.example/api`

Ingen API-nyckel ska läggas i appens källkod.
