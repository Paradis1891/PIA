package se.paradis1891.paradismarket

data class Instrument(val id: String, val name: String, val symbol: String, val currency: String)
data class Quote(
    val instrumentId: String,
    val price: Double,
    val changePercent: Double,
    val updatedAt: String,
    val source: String
)

val initialInstruments = listOf(
    Instrument("saab-b", "SAAB B", "SAAB-B.ST", "SEK"),
    Instrument("gold", "Guld", "GOLD", "USD")
)
