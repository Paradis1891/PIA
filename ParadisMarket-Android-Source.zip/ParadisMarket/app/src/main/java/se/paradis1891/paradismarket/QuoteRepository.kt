package se.paradis1891.paradismarket

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Expected backend response:
 * {
 *   "quotes": [
 *     {"instrumentId":"saab-b","price":...,"changePercent":...,"updatedAt":"...","source":"..."}
 *   ]
 * }
 *
 * Configure MARKET_API_BASE_URL in ~/.gradle/gradle.properties or CI secrets.
 * The app intentionally does not invent quotes or claim direct Avanza access.
 */
class QuoteRepository {
    private val client = OkHttpClient.Builder()
        .callTimeout(8, TimeUnit.SECONDS)
        .build()

    suspend fun fetchQuotes(baseUrl: String): List<Quote> = withContext(Dispatchers.IO) {
        require(baseUrl.startsWith("https://")) { "Ange en giltig HTTPS-källa för marknadsdata." }
        val request = Request.Builder().url(baseUrl.trimEnd('/') + "/quotes").build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Datakällan svarade ${response.code}")
            val json = JSONObject(response.body?.string() ?: error("Tomt svar"))
            val array = json.getJSONArray("quotes")
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(Quote(
                        instrumentId = item.getString("instrumentId"),
                        price = item.getDouble("price"),
                        changePercent = item.getDouble("changePercent"),
                        updatedAt = item.optString("updatedAt", ""),
                        source = item.optString("source", "Okänd källa")
                    ))
                }
            }
        }
    }
}
